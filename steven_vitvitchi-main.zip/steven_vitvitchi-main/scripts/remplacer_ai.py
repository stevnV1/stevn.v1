from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont


X = 300
Y = 150
TAILLE = 200
COULEUR = (113, 244, 255)

DOSSIER_ASSETS = Path(__file__).resolve().parent.parent / "assets"
SOURCE = DOSSIER_ASSETS / "fond-puce.png.png"
DESTINATION = DOSSIER_ASSETS / "fond-puce.png"
POLICE = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")


def remplacer_le_texte():
    image = Image.open(SOURCE).convert("RGB")
    largeur, hauteur = image.size

    masque_texte = Image.new("L", image.size)
    dessin_masque = ImageDraw.Draw(masque_texte)
    dessin_masque.polygon(
        [
            (X + 2, Y + 205),
            (X + 56, Y + 3),
            (X + 117, Y + 3),
            (X + 171, Y + 205),
        ],
        fill=255,
    )
    dessin_masque.polygon(
        [(X + 62, Y + 130), (X + 86, Y + 58), (X + 109, Y + 130)],
        fill=0,
    )
    dessin_masque.rectangle(
        (X + 200, Y + 2, X + 258, Y + 205),
        fill=255,
    )

    masque_restauration = masque_texte.filter(ImageFilter.MaxFilter(19))
    zone = masque_restauration.getbbox()
    if zone is None:
        raise ValueError("Aucun pixel lumineux correspondant au texte « AI » n'a été détecté.")

    masque_restauration = masque_restauration.filter(ImageFilter.GaussianBlur(2))
    masque_binaire = masque_texte.filter(ImageFilter.MaxFilter(13)).load()
    gauche, haut, droite, bas = zone
    source = image.load()
    remplissage = image.copy()
    pixels_remplissage = remplissage.load()

    for y in range(max(0, haut - 16), min(hauteur, bas + 16)):
        for x in range(max(0, gauche - 16), min(largeur, droite + 16)):
            if masque_binaire[x, y]:
                sample_x = x - 190 if x < X + 190 else x + 120
                sample_x = min(max(sample_x, 0), largeur - 1)
                pixels_remplissage[x, y] = source[sample_x, y]

    remplissage = remplissage.filter(ImageFilter.GaussianBlur(1))
    resultat = Image.composite(remplissage, image, masque_restauration)

    font = ImageFont.truetype(str(POLICE), TAILLE)
    boite = font.getbbox("SV")
    largeur_texte = boite[2] - boite[0]
    hauteur_texte = boite[3] - boite[1]
    calque_texte = Image.new("RGBA", (largeur_texte, hauteur_texte))
    dessin = ImageDraw.Draw(calque_texte)
    dessin.text((-boite[0], -boite[1]), "SV", font=font, fill=(*COULEUR, 255))

    largeur_cible = round(TAILLE * 1.3)
    hauteur_cible = TAILLE
    calque_texte = calque_texte.resize(
        (largeur_cible, hauteur_cible), Image.Resampling.LANCZOS
    )
    masque_lueur = calque_texte.getchannel("A")
    masque_lueur_complet = Image.new("L", image.size)
    masque_lueur_complet.paste(masque_lueur, (X, Y))

    calque_lueur = Image.new("RGBA", image.size)
    for rayon, opacite in ((22, 90), (11, 125), (4, 175)):
        lueur = masque_lueur_complet.filter(ImageFilter.GaussianBlur(rayon))
        couleur_lueur = Image.new("RGBA", image.size, (*COULEUR, 0))
        couleur_lueur.putalpha(lueur.point(lambda valeur: valeur * opacite // 255))
        calque_lueur = Image.alpha_composite(calque_lueur, couleur_lueur)

    calque_texte_complet = Image.new("RGBA", image.size)
    calque_texte_complet.alpha_composite(calque_texte, (X, Y))
    resultat_rgba = resultat.convert("RGBA")
    resultat_rgba = Image.alpha_composite(resultat_rgba, calque_lueur)
    resultat_rgba = Image.alpha_composite(resultat_rgba, calque_texte_complet)
    resultat_rgba.save(DESTINATION, format="PNG")


if __name__ == "__main__":
    remplacer_le_texte()
